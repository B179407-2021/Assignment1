#!/usr/bin/bash

#####################################################################################################
#This Programme is to analyze the gene-expression level of targeted organism under different condition.
#In this case, it is Trypanosonma congolense. 
#Analysis Tools needed to be pre-installed: bowtie2, samtools, bedtools
#Data needed to be provided: samples RNAseq results, genome fasta, genome information bedfile
#Files generated for user:
#1.quality check result: qualitycheck_result.csv
#2.expression level comparation result: expression.csv 
#####################################################################################################

######################## PREPARATION: Download all the files needed and get current working directory
echo -e "\nDownloading data......"
cp /localdisk/data/BPSM/AY21/Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz .
cp /localdisk/data/BPSM/AY21/TriTrypDB-46_TcongolenseIL3000_2019.bed .
cp -r /localdisk/data/BPSM/AY21/fastq .
echo "Download files to the current directory"
path=$(pwd)
unset IFS
IFS=$'\t'
echo -e "Data downloaded\n"

######################## QUALITY CHECK PART1: Perform qualitycheck using fastqc
###### Current Directory: $PATH
echo "Performing quality check......"
mkdir qualitycheck_output
fastqc -o qualitycheck_output -q -t 32 ./fastq/*.fq.gz
echo -e "Quality check finished\n"

####################### QUALITY CHECK PART2: Assess the numbers and quality of the raw sequence data
####################### Generate qualitycheck_result.csv which contains modules results of all the samples

###### Unzip the zip files produced from fastqc
echo "Unzipping quality check results......"
for i in ./qualitycheck_output/*fastqc.zip
do
	unzip -q $i -d ./qualitycheck_output/
done
rm -f ./qualitycheck_output/*.zip
echo -e "Quality check result files unzipped\n" 

echo -e "Organizing quality check results......"
###### Save headers in file1.csv
echo -e "Paired_end_reads_ID
Basic_Statistics
Sequences_flagged_as_poor_quality
%GC
Per_base_sequence_quality
Per_sequence_quality_scores
Per_base_sequence_content
Per_sequence_GC_content
Per_base_N_content
Sequence_Length_Distribution
Sequence_Duplication_Levels
Overrepresented_Sequences
Adapter_Content"|paste -s >>file1.csv

###### Save sample IDs in file2,csv, and save quality check results in file3.csv
for dir in ./qualitycheck_output/*fastqc
do
	grep "Filename" $dir/fastqc_data.txt|awk '{FS='\t';{print $2;}}' | paste -s >> file2.csv	
	grep -v "#" $dir/fastqc_data.txt |grep ">>\|%GC\|Sequences flagged as poor quality" | grep -v ">>END" |
	awk '{FS="\t"; if($2!="Statistics"){print $2;};if($2=="Statistics"){print $3;}}'| paste -s >>file3.csv
done

######################## QUALITY CHECK PART3:Generate the final file: qualitycheck_result.csv
paste file2.csv file3.csv > file4.csv
cat file1.csv file4.csv > qualitycheck_result.csv
rm -f file*
echo -e "Quality check results are saved in qualitycheck_result.csv. Please check.\n"

####################### ALIGNMENT: Use bowtie2 to align sample sequences with genome sequences and convert them into sam files
echo "Building genome index......"
bowtie2-build -q TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz genome 
mv genome.*.bt2 ./fastq
echo -e "Genome index is successfully built\n"

###### Use a LONG FOR-LOOP to go through all the data
echo "Performing alignment and generating counts data......"
cd $path/fastq
###### FOR-LOOP BEGINS
for file in ./*_1.fq.gz
do
	
	name=${file:2:13}
	bowtie2 --local --quiet -p 32 -x genome -1 $name"_1.fq.gz" -2 $name"_2.fq.gz" -S $name.sam
	samtools view -bS $name.sam |samtools sort -o $name.bam
	samtools index $name.bam $name.bai
	echo $name" alignment finished"
####################### GENERATE COUNTS DATA: Count how many overlaps for each gene in each sample
##### Convert bam files to bed files  
	bedtools bamtobed -i $name.bam > $name.bed
##### Perform bedtools, use uniq to get counts data and save it in $name.count
	bedtools intersect -wa -wb -a $name.bed -b $path/TriTrypDB-46_TcongolenseIL3000_2019.bed |
	awk '{FS="\t";OFS="\t";{print $10,$11;}}' |sort| uniq -c| sed -E 's/^ *//; s/ /\t/'> $name.count
###### Extract Gene ID and Gene information from genome index bed file	
	sort -k4,4 $path/TriTrypDB-46_TcongolenseIL3000_2019.bed |cut -f 4,5 |
	awk '{$1=0 "\t" $1"\t"$2 }1' > index.count
###### For those genes that didn't express, append them in the $name.count and fill the blank with 0
	awk 'NR==FNR { h[$2] = $1; next }{ print $2,$1,h[$2]}' $name.count index.count |
	cut -d " " -f 3 > $name.total
	sed -i -e 's/^$/0/' $name.total
	echo $name" ""counts data generated"
done
###### FOR-LOOP ENDS 
echo -e "Congrats! All counts data generated. Thanks for waiting."
####################### ANALYZE COUNTS DATA
echo "Analyzing counts data......"
mkdir $path/counts
mv *.total $path/counts
###### Sort 100k.fqfiles by sample and time, and save it in information.txt
sort -k2,2 -k4,4 100k.fqfiles | grep -v "ID" > $path/counts/information.txt
cd $path/counts
###### For lines with the sample and time, save the ID in $treatment"_"$sample"_"$time.name
while read ID sample replicate time treatment end1 end2
do
	echo $treatment"_"$sample"_"$time >> name.txt
  	echo "100k."$ID".total" >> ./$treatment"_"$sample"_"$time.name
done < information.txt
cat name.txt | uniq > file4
rm -f name.txt

###### For the three IDs in .name, calculate the mean of their counts data and save it under .mean
for i in *name
do
	mapfile -t < $i
	paste "${MAPFILE[@]}" | column -s $'\t' -t > $i.add
	awk '{ sum=($1+$2+$3); if(sum!=0) ave=sum/3;else ave=0;print ave }' $i.add > $i.mean
done

###### Cancatenate *.mean together, and put column names and row names in the file
paste *.mean > expression_level.csv
cut -f 2,3 $path/fastq/index.count > rowname
paste rowname expression_level.csv > file1
echo -e "GeneID\nGene_Information" > file2
cat file2 file4 | tr "\n" "\t"> file3
cat file3 file1 > $path/expression.csv
rm -f file* 
echo "Counts data saved in expression.csv. Please check."
cd $path
